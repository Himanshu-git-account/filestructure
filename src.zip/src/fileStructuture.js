export const treeList = {
    id:1,
  fileName: "abc",
  child: [
    {  id:2,
      fileName: "shimmer",
      child: [
        {
            id:3,
          fileName: "global",
          child: [],
        },
      ],
    },
    {
        id:4,
        fileName: "another",
        child: [
          {
            id:5,
            fileName: "inside",
            child: [
                {
                    id:6,
                fileName: "right",
                child:[]
                }
            ],
          },
        ],
      },
  ],
};



